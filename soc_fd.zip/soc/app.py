"""
Portable Log Analysis System for Isolated Environment
Main Flask Application Entry Point
"""
from flask import Flask
from config import Config
from models.db import init_db
from routes.dashboard import dashboard_bp
from routes.upload import upload_bp
from routes.analysis import analysis_bp
from routes.logs import logs_bp
from routes.reports import reports_bp

def create_app():
    """Create and configure Flask application"""
    app = Flask(__name__)
    app.config.from_object(Config)
    
    # Initialize app directories
    Config.init_app(app)
    
    # Initialize database
    init_db()
    
    # Register blueprints
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(upload_bp)
    app.register_blueprint(analysis_bp)
    app.register_blueprint(logs_bp)
    app.register_blueprint(reports_bp)
    
    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True, host='0.0.0.0', port=5000)
