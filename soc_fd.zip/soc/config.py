"""
Configuration settings for the SOC Log Analysis System
"""
import os

class Config:
    """Application configuration"""
    SECRET_KEY = 'soc-log-analysis-secret-key-2025'
    UPLOAD_FOLDER = 'uploads'
    MAX_CONTENT_LENGTH = 100 * 1024 * 1024  # 100MB max file size
    DB_PATH = 'data/logs.db'
    ALLOWED_EXTENSIONS = {'log', 'txt', 'csv'}
    
    @staticmethod
    def init_app(app):
        """Initialize application directories"""
        os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
        os.makedirs('data', exist_ok=True)
