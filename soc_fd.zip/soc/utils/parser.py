"""
Log parsing engine using regex patterns
"""
import re
from datetime import datetime

class LogParser:
    """Regex-based log parser for various log formats"""
    
    # Common log patterns
    PATTERNS = [
        # Standard format: [TIMESTAMP] LEVEL SOURCE IP: MESSAGE
        re.compile(r'\[(\d{4}-\d{2}-\d{2}[\sT]\d{2}:\d{2}:\d{2}[\.\d]*)\]?\s*(\w+)\s+(\S+)\s+(\d+\.\d+\.\d+\.\d+):\s*(.+)', re.IGNORECASE),
        # Apache/Nginx style: IP - - [TIMESTAMP] "METHOD PATH" STATUS
        re.compile(r'(\d+\.\d+\.\d+\.\d+)\s+-\s+-\s+\[([^\]]+)\]\s+"([^"]+)"\s+(\d+)', re.IGNORECASE),
        # Simple format: TIMESTAMP LEVEL MESSAGE
        re.compile(r'(\d{4}-\d{2}-\d{2}[\sT]\d{2}:\d{2}:\d{2}[\.\d]*)\s+(\w+)\s+(.+)', re.IGNORECASE),
        # CSV format (if comma-separated)
        re.compile(r'([^,]+),([^,]+),([^,]+),([^,]+),([^,]+)', re.IGNORECASE),
    ]
    
    @staticmethod
    def parse_line(line, line_num=0):
        """Parse a single log line into structured format"""
        line = line.strip()
        if not line:
            return None
        
        # Try each pattern
        for pattern in LogParser.PATTERNS:
            match = pattern.match(line)
            if match:
                groups = match.groups()
                
                # Pattern 1: [TIMESTAMP] LEVEL SOURCE IP: MESSAGE
                if len(groups) >= 5 and '.' in groups[3] and groups[3].replace('.', '').isdigit():
                    return {
                        'timestamp': groups[0],
                        'log_level': groups[1].upper(),
                        'source_system': groups[2],
                        'ip_address': groups[3],
                        'message': groups[4]
                    }
                
                # Pattern 2: Apache/Nginx style
                if len(groups) >= 4 and '.' in groups[0] and groups[0].replace('.', '').isdigit():
                    return {
                        'timestamp': groups[1],
                        'log_level': 'INFO',
                        'source_system': 'web_server',
                        'ip_address': groups[0],
                        'message': f"{groups[2]} - Status: {groups[3]}"
                    }
                
                # Pattern 3: Simple format
                if len(groups) >= 3:
                    return {
                        'timestamp': groups[0],
                        'log_level': groups[1].upper(),
                        'source_system': 'unknown',
                        'ip_address': LogParser._extract_ip(groups[2]),
                        'message': groups[2]
                    }
                
                # Pattern 4: CSV format
                if len(groups) >= 5:
                    return {
                        'timestamp': groups[0],
                        'log_level': groups[1].upper(),
                        'source_system': groups[2],
                        'ip_address': groups[3],
                        'message': groups[4]
                    }
        
        # Fallback: extract what we can
        ip = LogParser._extract_ip(line)
        level = LogParser._extract_level(line)
        timestamp = LogParser._extract_timestamp(line)
        
        return {
            'timestamp': timestamp or datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'log_level': level or 'INFO',
            'source_system': 'unknown',
            'ip_address': ip or '0.0.0.0',
            'message': line
        }
    
    @staticmethod
    def _extract_ip(text):
        """Extract IP address from text"""
        ip_pattern = re.compile(r'\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\b')
        match = ip_pattern.search(text)
        return match.group(1) if match else None
    
    @staticmethod
    def _extract_level(text):
        """Extract log level from text"""
        levels = ['CRITICAL', 'ERROR', 'WARNING', 'INFO', 'DEBUG']
        text_upper = text.upper()
        for level in levels:
            if level in text_upper:
                return level
        return None
    
    @staticmethod
    def _extract_timestamp(text):
        """Extract timestamp from text"""
        timestamp_patterns = [
            re.compile(r'\d{4}-\d{2}-\d{2}[\sT]\d{2}:\d{2}:\d{2}'),
            re.compile(r'\d{2}/\w{3}/\d{4}:\d{2}:\d{2}:\d{2}'),
        ]
        for pattern in timestamp_patterns:
            match = pattern.search(text)
            if match:
                return match.group(0)
        return None
