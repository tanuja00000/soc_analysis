"""
Log analysis and anomaly detection engine
"""
import sqlite3
import pandas as pd
import numpy as np
from sklearn.ensemble import IsolationForest
from models.db import get_db_connection
from config import Config

class AnalysisEngine:
    """Log analysis and anomaly detection engine"""
    
    @staticmethod
    def get_statistics(upload_id=None):
        """Calculate statistics from logs"""
        conn = get_db_connection()
        
        if upload_id:
            query = "SELECT * FROM log_entries WHERE upload_id = ?"
            df = pd.read_sql_query(query, conn, params=(upload_id,))
        else:
            query = "SELECT * FROM log_entries"
            df = pd.read_sql_query(query, conn)
        
        conn.close()
        
        if df.empty:
            return {
                'total_logs': 0,
                'critical_count': 0,
                'error_count': 0,
                'warning_count': 0,
                'info_count': 0,
                'unique_ips': 0,
                'suspicious_ips': [],
                'anomaly_count': 0
            }
        
        stats = {
            'total_logs': len(df),
            'critical_count': len(df[df['log_level'] == 'CRITICAL']),
            'error_count': len(df[df['log_level'] == 'ERROR']),
            'warning_count': len(df[df['log_level'] == 'WARNING']),
            'info_count': len(df[df['log_level'] == 'INFO']),
            'unique_ips': df['ip_address'].nunique(),
            'anomaly_count': len(df[df['is_anomaly'] == 1])
        }
        
        # Identify suspicious IPs (high frequency or many errors)
        ip_stats = df.groupby('ip_address').agg({
            'id': 'count',
            'log_level': lambda x: (x == 'ERROR').sum() + (x == 'CRITICAL').sum() * 2
        }).reset_index()
        ip_stats.columns = ['ip_address', 'count', 'error_score']
        ip_stats['suspicious_score'] = ip_stats['count'] * 0.3 + ip_stats['error_score'] * 0.7
        suspicious_ips = ip_stats[ip_stats['suspicious_score'] > ip_stats['suspicious_score'].quantile(0.9)]
        stats['suspicious_ips'] = suspicious_ips['ip_address'].tolist()[:10]
        
        return stats
    
    @staticmethod
    def detect_anomalies(upload_id=None):
        """Detect anomalies using Isolation Forest"""
        conn = get_db_connection()
        
        if upload_id:
            query = "SELECT * FROM log_entries WHERE upload_id = ?"
            df = pd.read_sql_query(query, conn, params=(upload_id,))
        else:
            query = "SELECT * FROM log_entries"
            df = pd.read_sql_query(query, conn)
        
        conn.close()
        
        if df.empty or len(df) < 10:
            return
        
        # Feature engineering for anomaly detection
        df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce')
        df = df.dropna(subset=['timestamp'])
        
        # Create features
        features = []
        for idx, row in df.iterrows():
            # Time-based features
            hour = row['timestamp'].hour
            minute = row['timestamp'].minute
            
            # Log level encoding
            level_map = {'CRITICAL': 4, 'ERROR': 3, 'WARNING': 2, 'INFO': 1, 'DEBUG': 0}
            level_score = level_map.get(row['log_level'], 1)
            
            # IP frequency (count of same IP in window)
            ip_count = len(df[df['ip_address'] == row['ip_address']])
            
            features.append([hour, minute, level_score, ip_count])
        
        if len(features) < 10:
            return
        
        # Isolation Forest
        X = np.array(features)
        iso_forest = IsolationForest(contamination=0.1, random_state=42)
        anomalies = iso_forest.fit_predict(X)
        
        # Mark anomalies in database
        conn = get_db_connection()
        c = conn.cursor()
        
        for idx, (_, row) in enumerate(df.iterrows()):
            if anomalies[idx] == -1:
                c.execute('''
                    UPDATE log_entries 
                    SET is_anomaly = 1 
                    WHERE id = ?
                ''', (int(row['id']),))
        
        conn.commit()
        conn.close()
    
    @staticmethod
    def get_timeline_data(upload_id=None, hours=24):
        """Get timeline data for visualization"""
        conn = get_db_connection()
        
        if upload_id:
            query = "SELECT timestamp, log_level FROM log_entries WHERE upload_id = ?"
            df = pd.read_sql_query(query, conn, params=(upload_id,))
        else:
            query = "SELECT timestamp, log_level FROM log_entries"
            df = pd.read_sql_query(query, conn)
        
        conn.close()
        
        if df.empty:
            return {'labels': [], 'data': []}
        
        df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce')
        df = df.dropna(subset=['timestamp'])
        
        # Determine time range
        time_range = (df['timestamp'].max() - df['timestamp'].min()).total_seconds() / 60  # in minutes
        
        # Use appropriate time grouping based on data spread
        if time_range < 60:  # Less than 1 hour - use 1-minute intervals
            df['time_group'] = df['timestamp'].dt.floor('1min')
        elif time_range < 1440:  # Less than 24 hours - use 5-minute intervals
            df['time_group'] = df['timestamp'].dt.floor('5min')
        else:  # More than 24 hours - use hourly intervals
            df['time_group'] = df['timestamp'].dt.floor('H')
        
        timeline = df.groupby(['time_group', 'log_level']).size().reset_index(name='count')
        timeline = timeline.pivot(index='time_group', columns='log_level', values='count').fillna(0)
        
        # Format labels nicely
        if time_range < 60:
            labels = [h.strftime('%H:%M') for h in timeline.index]
        elif time_range < 1440:
            labels = [h.strftime('%H:%M') for h in timeline.index]
        else:
            labels = [h.strftime('%Y-%m-%d %H:00') for h in timeline.index]
        
        data = {}
        for level in ['CRITICAL', 'ERROR', 'WARNING', 'INFO']:
            if level in timeline.columns:
                data[level] = timeline[level].tolist()
            else:
                data[level] = [0] * len(labels)
        
        return {'labels': labels, 'data': data}
