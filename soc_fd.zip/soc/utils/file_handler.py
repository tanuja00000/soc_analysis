"""
File upload and parsing utilities
"""
import os
from datetime import datetime
from werkzeug.utils import secure_filename
from flask import current_app
from models.db import get_db_connection
from utils.parser import LogParser
from utils.analyzer import AnalysisEngine
from config import Config

def allowed_file(filename):
    """Check if file extension is allowed"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in Config.ALLOWED_EXTENSIONS

def parse_log_file(filepath, upload_id):
    """Parse log file and store in database"""
    parser = LogParser()
    conn = get_db_connection()
    c = conn.cursor()
    
    total_parsed = 0
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            for line_num, line in enumerate(f, 1):
                parsed = parser.parse_line(line, line_num)
                if parsed:
                    c.execute('''
                        INSERT INTO log_entries 
                        (upload_id, timestamp, log_level, source_system, ip_address, message)
                        VALUES (?, ?, ?, ?, ?, ?)
                    ''', (
                        upload_id,
                        parsed['timestamp'],
                        parsed['log_level'],
                        parsed['source_system'],
                        parsed['ip_address'],
                        parsed['message']
                    ))
                    total_parsed += 1
                
                if line_num % 1000 == 0:
                    conn.commit()
        
        conn.commit()
        
        # Update upload record
        c.execute('''
            UPDATE uploads 
            SET total_logs = ?, status = ? 
            WHERE id = ?
        ''', (total_parsed, 'completed', upload_id))
        conn.commit()
        
        # Run anomaly detection
        AnalysisEngine.detect_anomalies(upload_id)
        
    except Exception as e:
        c.execute('''
            UPDATE uploads 
            SET status = ? 
            WHERE id = ?
        ''', (f'error: {str(e)}', upload_id))
        conn.commit()
    finally:
        conn.close()

def save_uploaded_file(file, upload_folder):
    """Save uploaded file and return filepath and upload_id"""
    filename = secure_filename(file.filename)
    upload_id = f"{datetime.now().strftime('%Y%m%d%H%M%S')}_{filename}"
    filepath = os.path.join(upload_folder, upload_id)
    file.save(filepath)
    return filepath, upload_id
