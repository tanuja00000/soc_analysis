# 📦 How to Share and Run This Project

## For You (Sharing the Project)

### Option 1: Zip File (Easiest)
1. **Exclude unnecessary files:**
   - Don't include the `venv/` folder (too large)
   - Don't include `__pycache__/` folders
   - Don't include `data/logs.db` (if it has personal data)

2. **Create a zip file:**
   - Select all project files EXCEPT `venv/` and `__pycache__/`
   - Right-click → Send to → Compressed (zipped) folder
   - Name it: `soc-log-analysis.zip`

3. **Send to your friend:**
   - Email, USB drive, Google Drive, etc.

### Option 2: GitHub (Recommended)
1. Create a new repository on GitHub
2. Upload all files (except `venv/`, `__pycache__/`, `data/logs.db`)
3. Share the repository link with your friend

---

## For Your Friend (Running the Project)

### Step 1: Extract/Download
- If zip file: Extract to a folder (e.g., `C:\Users\YourName\Desktop\soc`)
- If GitHub: Clone or download the repository

### Step 2: Install Python
- Check if Python is installed: Open Command Prompt and type `python --version`
- If not installed: Download from [python.org](https://www.python.org/downloads/)
- **Important:** Check "Add Python to PATH" during installation

### Step 3: Setup (One-Time)
1. Open Command Prompt in the project folder
2. Run:
   ```bash
   setup.bat
   ```
   This will:
   - Create virtual environment
   - Install all required packages
   - Take 2-5 minutes (first time only)

### Step 4: Run the Application
1. Double-click `run.bat` (or run it from Command Prompt)
2. Wait for: `Running on http://127.0.0.1:5000`
3. Open browser and go to: `http://localhost:5000`

### Step 5: Use the Application
1. Click "Upload Logs"
2. Upload a `.log`, `.txt`, or `.csv` file
3. Wait for processing
4. View analysis, charts, and reports!

---

## Quick Troubleshooting

**Problem:** "python is not recognized"
- **Solution:** Python not installed or not in PATH. Reinstall Python and check "Add to PATH"

**Problem:** "setup.bat" doesn't work
- **Solution:** Open Command Prompt, navigate to project folder, run:
  ```bash
  python -m venv venv
  venv\Scripts\activate
  pip install -r requirements.txt
  ```

**Problem:** Charts not showing
- **Solution:** Make sure `static/charts/chart.min.js` file exists

**Problem:** Port 5000 already in use
- **Solution:** Close other applications using port 5000, or change port in `app.py` (line 37)

---

## What Files to Share

✅ **Include:**
- All `.py` files (app.py, config.py, etc.)
- `requirements.txt`
- `setup.bat` and `run.bat`
- `templates/` folder
- `static/` folder
- `README.md`
- `sample_logs.log` (for testing)

❌ **Don't Include:**
- `venv/` folder (too large, will be recreated)
- `__pycache__/` folders
- `data/logs.db` (if contains personal data)
- `.git/` folder (if using git)

---

## System Requirements

- **OS:** Windows 10/11 (or Linux/Mac with minor script changes)
- **Python:** 3.8 or higher
- **RAM:** 2GB minimum
- **Disk Space:** ~500MB (after setup)

---

## Alternative: Manual Setup

If batch files don't work, your friend can run these commands manually:

```bash
# 1. Create virtual environment
python -m venv venv

# 2. Activate it
venv\Scripts\activate

# 3. Install packages
pip install -r requirements.txt

# 4. Run the app
python app.py
```

Then open `http://localhost:5000` in browser.

---

**That's it!** Your friend should be able to run the project in 5-10 minutes. 🚀
