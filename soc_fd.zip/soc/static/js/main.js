/**
 * SOC Log Analysis System - Main JavaScript
 */

// Utility functions
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleString();
}

function showAlert(message, type = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type}`;
    alertDiv.textContent = message;
    
    const container = document.querySelector('.main-content');
    container.insertBefore(alertDiv, container.firstChild);
    
    setTimeout(() => {
        alertDiv.remove();
    }, 5000);
}

// Auto-refresh dashboard stats
if (window.location.pathname === '/') {
    setInterval(() => {
        fetch('/api/stats')
            .then(response => response.json())
            .then(data => {
                // Update stats if needed
                console.log('Stats updated:', data);
            })
            .catch(error => console.error('Error fetching stats:', error));
    }, 30000); // Refresh every 30 seconds
}

// Table row highlighting
document.addEventListener('DOMContentLoaded', function() {
    const criticalRows = document.querySelectorAll('.row-critical');
    criticalRows.forEach(row => {
        row.addEventListener('click', function() {
            this.style.outline = '2px solid #ef4444';
            setTimeout(() => {
                this.style.outline = '';
            }, 2000);
        });
    });
});

// Export functionality
function exportData(format) {
    const uploadId = new URLSearchParams(window.location.search).get('upload_id');
    let url = `/api/generate_report?type=${format}`;
    if (uploadId) {
        url += `&upload_id=${uploadId}`;
    }
    window.location.href = url;
}
