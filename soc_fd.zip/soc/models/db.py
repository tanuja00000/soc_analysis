"""
Database models and initialization
"""
import sqlite3
from config import Config

def get_db_connection():
    """Get database connection"""
    return sqlite3.connect(Config.DB_PATH)

def init_db():
    """Initialize SQLite database for storing parsed logs"""
    conn = get_db_connection()
    c = conn.cursor()
    
    # Create log_entries table
    c.execute('''
        CREATE TABLE IF NOT EXISTS log_entries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            upload_id TEXT NOT NULL,
            timestamp TEXT,
            log_level TEXT,
            source_system TEXT,
            ip_address TEXT,
            message TEXT,
            is_anomaly INTEGER DEFAULT 0,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Create uploads table
    c.execute('''
        CREATE TABLE IF NOT EXISTS uploads (
            id TEXT PRIMARY KEY,
            filename TEXT,
            file_size INTEGER,
            upload_time TEXT,
            total_logs INTEGER DEFAULT 0,
            status TEXT DEFAULT 'pending'
        )
    ''')
    
    conn.commit()
    conn.close()
