"""Database models and initialization"""
