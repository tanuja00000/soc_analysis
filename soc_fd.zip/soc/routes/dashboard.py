"""
Dashboard routes
"""
from flask import Blueprint, render_template
from models.db import get_db_connection
from utils.analyzer import AnalysisEngine

dashboard_bp = Blueprint('dashboard', __name__)

@dashboard_bp.route('/')
def index():
    """Home dashboard"""
    conn = get_db_connection()
    c = conn.cursor()
    
    # Get recent uploads
    c.execute('''
        SELECT id, filename, upload_time, total_logs, status 
        FROM uploads 
        ORDER BY upload_time DESC 
        LIMIT 10
    ''')
    uploads = [dict(zip(['id', 'filename', 'upload_time', 'total_logs', 'status'], row)) 
               for row in c.fetchall()]
    
    # Get overall statistics
    stats = AnalysisEngine.get_statistics()
    
    conn.close()
    
    return render_template('dashboard.html', uploads=uploads, stats=stats)
