"""
File upload routes
"""
import os
from flask import Blueprint, render_template, request, jsonify
from datetime import datetime
from models.db import get_db_connection
from utils.file_handler import allowed_file, save_uploaded_file, parse_log_file
from config import Config

upload_bp = Blueprint('upload', __name__)

@upload_bp.route('/upload', methods=['GET', 'POST'])
def upload():
    """Log file upload endpoint"""
    if request.method == 'POST':
        if 'file' not in request.files:
            return jsonify({'error': 'No file provided'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        if file and allowed_file(file.filename):
            filepath, upload_id = save_uploaded_file(file, Config.UPLOAD_FOLDER)
            file_size = os.path.getsize(filepath)
            
            # Store upload record
            conn = get_db_connection()
            c = conn.cursor()
            c.execute('''
                INSERT INTO uploads (id, filename, file_size, upload_time, status)
                VALUES (?, ?, ?, ?, ?)
            ''', (upload_id, file.filename, file_size, datetime.now().isoformat(), 'processing'))
            conn.commit()
            conn.close()
            
            # Parse logs in background
            parse_log_file(filepath, upload_id)
            
            return jsonify({
                'success': True,
                'upload_id': upload_id,
                'message': 'File uploaded and processing started'
            })
    
    return render_template('upload.html')
