"""
Log details and filtering routes
"""
from flask import Blueprint, render_template, request
from models.db import get_db_connection

logs_bp = Blueprint('logs', __name__)

@logs_bp.route('/logs')
def logs():
    """Log details page with filtering"""
    upload_id = request.args.get('upload_id')
    level_filter = request.args.get('level', '')
    ip_filter = request.args.get('ip', '')
    search = request.args.get('search', '')
    page = int(request.args.get('page', 1))
    per_page = 100
    
    conn = get_db_connection()
    c = conn.cursor()
    
    # Build query
    query = "SELECT * FROM log_entries WHERE 1=1"
    params = []
    
    if upload_id:
        query += " AND upload_id = ?"
        params.append(upload_id)
    
    if level_filter:
        query += " AND log_level = ?"
        params.append(level_filter)
    
    if ip_filter:
        query += " AND ip_address = ?"
        params.append(ip_filter)
    
    if search:
        query += " AND (message LIKE ? OR ip_address LIKE ?)"
        params.extend([f'%{search}%', f'%{search}%'])
    
    query += " ORDER BY timestamp DESC LIMIT ? OFFSET ?"
    params.extend([per_page, (page - 1) * per_page])
    
    c.execute(query, params)
    logs_data = [dict(zip(['id', 'upload_id', 'timestamp', 'log_level', 'source_system', 
                          'ip_address', 'message', 'is_anomaly', 'created_at'], row)) 
                 for row in c.fetchall()]
    
    # Get unique values for filters
    c.execute("SELECT DISTINCT log_level FROM log_entries")
    levels = [row[0] for row in c.fetchall()]
    
    c.execute("SELECT DISTINCT ip_address FROM log_entries LIMIT 50")
    ips = [row[0] for row in c.fetchall()]
    
    conn.close()
    
    return render_template('logs.html', logs=logs_data, levels=levels, ips=ips, 
                         current_level=level_filter, current_ip=ip_filter, 
                         current_search=search, page=page, upload_id=upload_id)
