"""Flask routes for the application"""
