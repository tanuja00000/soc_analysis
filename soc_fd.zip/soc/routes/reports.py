"""
Report generation routes
"""
from flask import Blueprint, render_template, request, jsonify, send_file
from datetime import datetime
import pandas as pd
import json
import csv
from io import BytesIO
from models.db import get_db_connection
from utils.analyzer import AnalysisEngine

reports_bp = Blueprint('reports', __name__)

@reports_bp.route('/reports')
def reports():
    """Reports page"""
    upload_id = request.args.get('upload_id')
    return render_template('reports.html', upload_id=upload_id)

@reports_bp.route('/api/generate_report')
def generate_report():
    """Generate and download report"""
    upload_id = request.args.get('upload_id')
    report_type = request.args.get('type', 'csv')  # csv, json, pdf
    
    conn = get_db_connection()
    
    if upload_id:
        query = "SELECT * FROM log_entries WHERE upload_id = ?"
        df = pd.read_sql_query(query, conn, params=(upload_id,))
    else:
        query = "SELECT * FROM log_entries"
        df = pd.read_sql_query(query, conn)
    
    conn.close()
    
    stats = AnalysisEngine.get_statistics(upload_id)
    
    if report_type == 'csv':
        output = BytesIO()
        writer = csv.writer(output)
        
        # Write summary
        writer.writerow(['Report Summary'])
        writer.writerow(['Total Logs', stats['total_logs']])
        writer.writerow(['Critical Logs', stats['critical_count']])
        writer.writerow(['Error Logs', stats['error_count']])
        writer.writerow(['Anomalies Detected', stats['anomaly_count']])
        writer.writerow([])
        writer.writerow(['Log Details'])
        writer.writerow(['Timestamp', 'Level', 'Source', 'IP', 'Message', 'Anomaly'])
        
        for _, row in df.iterrows():
            writer.writerow([
                row['timestamp'],
                row['log_level'],
                row['source_system'],
                row['ip_address'],
                row['message'],
                'Yes' if row['is_anomaly'] else 'No'
            ])
        
        output.seek(0)
        return send_file(output, mimetype='text/csv', 
                        as_attachment=True, 
                        download_name=f'report_{upload_id or "all"}.csv')
    
    elif report_type == 'json':
        report_data = {
            'summary': stats,
            'logs': df.to_dict('records'),
            'generated_at': datetime.now().isoformat()
        }
        output = BytesIO()
        output.write(json.dumps(report_data, indent=2).encode())
        output.seek(0)
        return send_file(output, mimetype='application/json',
                        as_attachment=True,
                        download_name=f'report_{upload_id or "all"}.json')
    
    else:  # PDF - simplified text version (using basic text if reportlab not available)
        try:
            from reportlab.lib.pagesizes import letter
            from reportlab.pdfgen import canvas
            
            output = BytesIO()
            p = canvas.Canvas(output, pagesize=letter)
            width, height = letter
            
            y = height - 50
            p.drawString(50, y, "Log Analysis Report")
            y -= 30
            
            p.drawString(50, y, f"Total Logs: {stats['total_logs']}")
            y -= 20
            p.drawString(50, y, f"Critical: {stats['critical_count']}")
            y -= 20
            p.drawString(50, y, f"Errors: {stats['error_count']}")
            y -= 20
            p.drawString(50, y, f"Anomalies: {stats['anomaly_count']}")
            y -= 30
            
            p.drawString(50, y, "Critical Log Entries:")
            y -= 20
            
            critical_logs = df[df['log_level'] == 'CRITICAL'].head(20)
            for _, row in critical_logs.iterrows():
                if y < 50:
                    p.showPage()
                    y = height - 50
                p.drawString(50, y, f"{row['timestamp']} - {row['message'][:60]}")
                y -= 15
            
            p.save()
            output.seek(0)
            return send_file(output, mimetype='application/pdf',
                            as_attachment=True,
                            download_name=f'report_{upload_id or "all"}.pdf')
        except ImportError:
            # Fallback to CSV if reportlab not available
            return jsonify({'error': 'PDF generation requires reportlab. Install with: pip install reportlab'}), 400
