"""
Analysis and API routes
"""
from flask import Blueprint, render_template, request, jsonify
from utils.analyzer import AnalysisEngine

analysis_bp = Blueprint('analysis', __name__)

@analysis_bp.route('/analysis')
def analysis():
    """Analysis dashboard with charts"""
    upload_id = request.args.get('upload_id')
    stats = AnalysisEngine.get_statistics(upload_id)
    timeline = AnalysisEngine.get_timeline_data(upload_id)
    
    return render_template('analysis.html', stats=stats, timeline=timeline, upload_id=upload_id)

@analysis_bp.route('/api/stats')
def api_stats():
    """API endpoint for statistics"""
    upload_id = request.args.get('upload_id')
    stats = AnalysisEngine.get_statistics(upload_id)
    return jsonify(stats)

@analysis_bp.route('/api/timeline')
def api_timeline():
    """API endpoint for timeline data"""
    upload_id = request.args.get('upload_id')
    timeline = AnalysisEngine.get_timeline_data(upload_id)
    return jsonify(timeline)
