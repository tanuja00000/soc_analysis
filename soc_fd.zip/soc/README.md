# Portable Log Analysis System for Isolated Environment

A fully offline, portable SOC-style log analysis system designed to run in isolated environments with no internet access. This system allows users to upload log files, parse them into structured data, analyze them, detect anomalies, and visualize results in a professional dashboard.

## 🛡️ Features

- **Fully Offline**: No external APIs, CDNs, or cloud dependencies
- **Log Parsing**: Regex-based parser supporting multiple log formats (.log, .txt, .csv)
- **Anomaly Detection**: Isolation Forest algorithm for detecting suspicious patterns
- **Visualization**: Interactive charts using Chart.js (local copy)
- **Export Reports**: Generate reports in CSV, JSON, and PDF formats
- **Professional UI**: SOC-style dashboard with real-time statistics
- **Filtering & Search**: Advanced filtering by log level, IP address, and keywords

## 📋 Requirements

- Python 3.8 or higher
- All dependencies listed in `requirements.txt`

## 🚀 Installation

1. Clone or download this repository
2. Create a virtual environment (recommended):
   ```bash
   python -m venv venv
   ```
3. Activate the virtual environment:
   - **Windows**: `venv\Scripts\activate`
   - **Linux/Mac**: `source venv/bin/activate`
4. Install Python dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## 📤 Sharing This Project

**Quick Share Guide:**
1. Zip all files EXCEPT `venv/` folder
2. Send to friend
3. Friend runs `setup.bat` then `run.bat`
4. Done!

See `SHARING_GUIDE.md` for detailed instructions.

## 🏃 Running the Application

### Quick Start (Windows)

1. **First time setup:**
   ```bash
   setup.bat          # Standard setup
   setup_fast.bat      # Faster setup (uses pre-built wheels)
   ```

2. **Run the application:**
   ```bash
   run.bat             # Command Prompt
   run_powershell.bat  # PowerShell (handles execution policy)
   ```
   Or manually:
   ```bash
   python app.py
   ```

3. **Open your browser:**
   ```
   http://localhost:5000
   ```

### Manual Start

1. Activate virtual environment:
   ```bash
   venv\Scripts\activate  # Windows
   source venv/bin/activate  # Linux/Mac
   ```

2. Start the Flask server:
   ```bash
   python app.py
   ```

3. Open your web browser and navigate to:
   ```
   http://localhost:5000
   ```

## 📁 Project Structure

```
soc/
├── app.py                 # Main Flask application
├── requirements.txt       # Python dependencies
├── README.md             # This file
├── data/                 # SQLite database and data storage
│   └── logs.db
├── uploads/              # Uploaded log files
├── static/               # Static assets
│   ├── css/
│   │   └── style.css
│   ├── js/
│   │   └── main.js
│   └── charts/
│       └── chart.min.js  # Local Chart.js (offline)
└── templates/            # HTML templates
    ├── base.html
    ├── dashboard.html
    ├── upload.html
    ├── analysis.html
    ├── logs.html
    └── reports.html
```

## 🔧 System Architecture

```
User
  ↓
Dashboard UI
  ↓
Log Upload Module
  ↓
Log Parsing Engine (Regex)
  ↓
Analysis Engine
  ↓
Anomaly Detection Engine (Isolation Forest)
  ↓
Visualization & Reports
```

## 📊 Functional Modules

### 1. Dashboard Module
- Landing page with summary cards
- Recent log uploads list
- Quick overview metrics

### 2. Log Upload Module
- Accepts .log, .txt, .csv files
- Validates file size (max 100MB)
- Stores logs locally
- Automatically triggers parsing

### 3. Log Parsing Module
- Regex-based parser
- Extracts: Timestamp, Log Level, Source System, IP Address, Message
- Supports multiple log formats

### 4. Log Analysis Module
- Total log count
- Critical/Error/Warning/Info counts
- Suspicious IP identification
- Anomaly detection statistics

### 5. Anomaly Detection Module
- Uses Isolation Forest algorithm
- Detects:
  - Excessive failed login attempts
  - Repeated requests from same IP
  - Sudden spikes in ERROR/CRITICAL logs

### 6. Visualization Module
- Bar chart for log level distribution
- Timeline chart for log activity
- Alert indicators for anomalies

### 7. Log Details & Filtering Module
- Detailed log table
- Filter by log level, source system, IP
- Search by keyword
- Highlight CRITICAL and anomalous entries

### 8. Reports & Export Module
- Generate reports in CSV, JSON, PDF formats
- Includes summary statistics, anomalies, and critical entries

## 📝 Log Format Examples

The parser supports various log formats:

**Standard Format:**
```
[2025-01-10 10:45:32] ERROR system 192.168.1.10: Unauthorized access attempt
```

**Simple Format:**
```
2025-01-10 10:45:32 ERROR Failed login from 192.168.1.10
```

**CSV Format:**
```
2025-01-10 10:45:32,ERROR,system,192.168.1.10,Message content
```

## 🎯 Usage Guide

1. **Upload Logs**: Navigate to "Upload Logs" and select your log file
2. **View Dashboard**: Check summary statistics and recent uploads
3. **Analyze**: Click "Analyze" to view detailed analysis with charts
4. **Filter Logs**: Use "Log Details" to filter and search through entries
5. **Generate Reports**: Export analysis results in your preferred format

## 🔒 Security Features

- Offline operation (no external connections)
- Local data storage (SQLite)
- File size validation
- Secure filename handling

## 🛠️ Technology Stack

- **Backend**: Python (Flask)
- **Data Processing**: Pandas
- **Anomaly Detection**: scikit-learn (Isolation Forest)
- **Frontend**: HTML, CSS, JavaScript
- **Visualization**: Chart.js (local copy)
- **Storage**: SQLite

## 📄 License

This project is designed for educational purposes, hackathons, and cybersecurity portfolios.

## 🤝 Contributing

This is a standalone project designed for isolated environments. All assets are bundled locally to ensure complete offline functionality.

## ⚠️ Notes

- The system is designed to run completely offline
- All JavaScript libraries (Chart.js) are included locally
- No internet connection is required after installation
- Suitable for air-gapped environments

## 📞 Support

For issues or questions, refer to the code comments and documentation within the source files.

---

**Built for SOC-style log analysis in isolated environments** 🛡️
