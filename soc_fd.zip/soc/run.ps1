# PowerShell script to run SOC Log Analysis System
# Run with: powershell -ExecutionPolicy Bypass -File .\run.ps1

Write-Host "Starting SOC Log Analysis System..." -ForegroundColor Green
Write-Host ""

# Check if venv exists and activate it
if (Test-Path "venv\Scripts\Activate.ps1") {
    Write-Host "Activating virtual environment..." -ForegroundColor Yellow
    & "venv\Scripts\Activate.ps1"
    Write-Host "Virtual environment activated." -ForegroundColor Green
} else {
    Write-Host "Warning: Virtual environment not found. Using system Python." -ForegroundColor Yellow
    Write-Host "Run setup.bat first to create venv (recommended)." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Starting Flask server..." -ForegroundColor Cyan
Write-Host "Open http://localhost:5000 in your browser" -ForegroundColor Cyan
Write-Host "Press Ctrl+C to stop" -ForegroundColor Cyan
Write-Host ""

python app.py
